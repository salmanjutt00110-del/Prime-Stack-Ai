import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  ArrowLeft, Check, ShieldCheck, PackageCheck, ListChecks,
  MessageCircle, AlertTriangle, ClipboardList, Star,
} from "lucide-react";
import { ALL_PRODUCTS, BRAND, BUYING_STEPS } from "@/data/products";
import { openWhatsApp, WHATSAPP_GENERAL, WHATSAPP_NUMBER } from "@/lib/whatsapp";

function Section({ icon: Icon, title, accent, children }) {
  return (
    <div
      className="rounded-2xl p-6"
      style={{
        background: "rgba(255,255,255,0.03)",
        backdropFilter: "blur(20px)",
        border: "1px solid rgba(255,255,255,0.07)",
      }}
    >
      <div className="flex items-center gap-2.5 mb-4">
        <div
          className="flex items-center justify-center rounded-lg"
          style={{ width: 34, height: 34, background: `${accent}1a`, border: `1px solid ${accent}33` }}
        >
          <Icon size={17} style={{ color: accent }} />
        </div>
        <h3 className="font-display font-semibold text-white text-lg">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function List({ items, accent }) {
  return (
    <ul className="space-y-2.5">
      {items.map((it) => (
        <li key={it} className="flex items-start gap-2.5 text-sm text-white/65 leading-relaxed">
          <Check size={16} className="mt-0.5 shrink-0" style={{ color: accent }} />
          <span>{it}</span>
        </li>
      ))}
    </ul>
  );
}

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = ALL_PRODUCTS.find((p) => p.id === id);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);
  useEffect(() => {
    // reveal animation
    const els = document.querySelectorAll(".ps-reveal");
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.style.opacity = "1";
            e.target.style.transform = "translateY(0)";
            obs.unobserve(e.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    els.forEach((el) => {
      el.style.opacity = "0";
      el.style.transform = "translateY(30px)";
      el.style.transition = "opacity 0.6s cubic-bezier(0.16,1,0.3,1), transform 0.6s cubic-bezier(0.16,1,0.3,1)";
      obs.observe(el);
    });
    return () => obs.disconnect();
  }, [id]);

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#050505] text-white px-6">
        <h1 className="font-display text-2xl font-bold mb-3">Product not found</h1>
        <p className="text-white/50 mb-6">The product you're looking for doesn't exist.</p>
        <button
          onClick={() => navigate("/")}
          className="px-6 py-3 rounded-xl text-sm font-semibold text-white border border-white/15 hover:bg-white/8 transition-colors"
        >
          Back to Home
        </button>
      </div>
    );
  }

  const accent = product.color;

  return (
    <div className="relative min-h-screen bg-[#050505] text-white overflow-x-hidden pt-16">
      {/* ambient bg */}
      <div
        className="absolute inset-0 -z-10"
        style={{
          background: `radial-gradient(ellipse 80% 50% at 50% 0%, ${accent}1a, transparent 70%)`,
        }}
      />
      <div
        className="absolute -z-10 rounded-full blur-[120px] opacity-40"
        style={{ width: 400, height: 400, top: 40, left: "55%", background: `${accent}40` }}
      />

      {/* back */}
      <div className="mx-auto max-w-5xl px-4 sm:px-6 pt-8">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm text-white/60 hover:text-white transition-colors"
        >
          <ArrowLeft size={16} /> Back
        </button>
      </div>

      {/* hero */}
      <div className="mx-auto max-w-5xl px-4 sm:px-6 py-10 grid md:grid-cols-2 gap-10 items-center">
        <div>
          {product.tag && (
            <span
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-4"
              style={{ background: `${accent}1a`, border: `1px solid ${accent}40`, color: accent }}
            >
              {product.tag}
            </span>
          )}
          <h1 className="font-display font-bold text-white text-[clamp(2rem,5vw,3.2rem)] leading-[1.05] tracking-tight">
            {product.name}
          </h1>
          <p className="mt-4 text-white/60 text-base leading-relaxed max-w-lg">
            {product.description}
          </p>

          <div className="mt-6 flex items-center gap-3 flex-wrap">
            {product.oldPrice && (
              <span className="text-white/35 text-lg line-through">{product.oldPrice}</span>
            )}
            <span className="text-3xl font-bold" style={{ color: accent }}>{product.price}</span>
            <span className="ps-pulse px-2.5 py-1 rounded-full text-xs font-bold bg-white/8 border border-white/15 bg-gradient-to-r from-blue-400 via-violet-400 to-pink-400 bg-clip-text text-transparent">
              10% OFF
            </span>
          </div>

          <div className="mt-4 flex items-center gap-2 text-white/50 text-sm">
            <Star size={15} className="text-yellow-400 fill-yellow-400" />
            <Star size={15} className="text-yellow-400 fill-yellow-400" />
            <Star size={15} className="text-yellow-400 fill-yellow-400" />
            <Star size={15} className="text-yellow-400 fill-yellow-400" />
            <Star size={15} className="text-yellow-400 fill-yellow-400" />
            <span className="ml-1">Trusted by 500+ happy clients</span>
          </div>

          <div className="mt-7 flex items-center gap-3 flex-wrap">
            <button
              onClick={() => openWhatsApp(product.name, product.duration, product.price)}
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl text-sm font-semibold text-white transition-all duration-300 hover:scale-[1.02]"
              style={{ background: "linear-gradient(135deg, #25D366, #128C7E)", boxShadow: `0 4px 24px ${accent}40` }}
            >
              <MessageCircle size={16} /> Buy on WhatsApp
            </button>
            <a
              href="#details"
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl text-sm font-semibold text-white border border-white/15 bg-white/5 hover:bg-white/10 transition-all"
            >
              View Details
            </a>
          </div>
        </div>

        {/* logo card */}
        <div className="flex justify-center">
          <div className="relative">
            <div className="absolute inset-0 rounded-[2rem] blur-[60px]" style={{ background: `${accent}50` }} />
            <div
              className="ps-float relative flex items-center justify-center rounded-[2rem]"
              style={{
                width: "min(70vw, 260px)",
                height: "min(70vw, 260px)",
                background: "rgba(255,255,255,0.04)",
                backdropFilter: "blur(40px)",
                border: "1px solid rgba(255,255,255,0.12)",
                boxShadow: `0 24px 80px rgba(0,0,0,0.5), 0 0 60px ${accent}30`,
              }}
            >
              <span className="ps-shimmer absolute inset-0 rounded-[2rem] overflow-hidden" />
              <img src={product.logo} alt={product.name} className="relative w-1/2 h-1/2 object-contain" />
            </div>
          </div>
        </div>
      </div>

      {/* key features strip */}
      <div className="mx-auto max-w-5xl px-4 sm:px-6 pb-6">
        <div
          className="grid grid-cols-2 sm:grid-cols-4 gap-3 rounded-2xl p-5"
          style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
        >
          <Stat icon={PackageCheck} label="Duration" value={product.duration} accent={accent} />
          <Stat icon={ShieldCheck} label="Warranty" value={product.warrantyPolicy[0]} accent={accent} small />
          <Stat icon={ListChecks} label="Features" value={`${product.features.length} included`} accent={accent} />
          <Stat icon={MessageCircle} label="Delivery" value="WhatsApp" accent={accent} />
        </div>
      </div>

      {/* detail sections */}
      <div id="details" className="mx-auto max-w-5xl px-4 sm:px-6 py-8 space-y-5">
        <div className="ps-reveal grid md:grid-cols-2 gap-5">
          <Section icon={ListChecks} title="Key Features" accent={accent}>
            <List items={product.features} accent={accent} />
          </Section>
          <Section icon={PackageCheck} title="What's Included" accent={accent}>
            <List items={product.whatsIncluded} accent={accent} />
          </Section>
        </div>

        {product.requirements && product.requirements.length > 0 && (
          <div className="ps-reveal">
            <Section icon={ClipboardList} title="Requirements" accent={accent}>
              <List items={product.requirements} accent={accent} />
            </Section>
          </div>
        )}

        <div className="ps-reveal">
          <Section icon={AlertTriangle} title="Terms of Use" accent={accent}>
            <List items={product.termsOfUse} accent={accent} />
          </Section>
        </div>

        <div className="ps-reveal">
          <Section icon={ShieldCheck} title="Warranty & Support Policy" accent={accent}>
            <List items={product.warrantyPolicy} accent={accent} />
          </Section>
        </div>

        {/* buying instructions */}
        <div className="ps-reveal rounded-2xl p-6" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
          <h3 className="font-display font-semibold text-white text-lg mb-5">How to Buy This Product</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {BUYING_STEPS.map((s, i) => (
              <div key={s.title} className="relative rounded-xl p-4" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                <div className="absolute top-3 right-4 font-display font-bold text-3xl text-white/5">{i + 1}</div>
                <div className="text-sm font-semibold text-white mb-1">{s.title}</div>
                <p className="text-xs text-white/50 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* bottom CTA */}
      <div className="mx-auto max-w-5xl px-4 sm:px-6 pb-12">
        <div
          className="rounded-2xl p-8 text-center relative overflow-hidden"
          style={{
            background: `linear-gradient(135deg, ${accent}1a, rgba(139,92,246,0.12))`,
            border: "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <h3 className="font-display font-bold text-white text-xl sm:text-2xl">
            Ready to get {product.name}?
          </h3>
          <p className="mt-2 text-white/60 text-sm max-w-md mx-auto">
            Order now on WhatsApp — your product details are pre-filled. Pay, activate, and start using premium access.
          </p>
          <div className="mt-5 flex items-center justify-center gap-3 flex-wrap">
            <button
              onClick={() => openWhatsApp(product.name, product.duration, product.price)}
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl text-sm font-semibold text-white transition-all hover:scale-[1.02]"
              style={{ background: "linear-gradient(135deg, #25D366, #128C7E)" }}
            >
              <MessageCircle size={16} /> Buy on WhatsApp
            </button>
            <a
              href={WHATSAPP_GENERAL}
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3.5 rounded-xl text-sm font-semibold text-white border border-white/15 hover:bg-white/8 transition-colors"
            >
              Ask a Question
            </a>
          </div>
          <p className="mt-4 text-white/30 text-xs">WhatsApp: +{WHATSAPP_NUMBER}</p>
        </div>
      </div>

      {/* explore more */}
      <div className="mx-auto max-w-5xl px-4 sm:px-6 pb-16 text-center">
        <Link to="/#products" className="text-sm text-white/60 hover:text-white transition-colors">
          ← Explore more products
        </Link>
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value, accent, small }) {
  return (
    <div className="flex items-center gap-3">
      <Icon size={18} style={{ color: accent }} className="shrink-0" />
      <div className="min-w-0">
        <div className="text-[10px] uppercase tracking-wide text-white/40">{label}</div>
        <div className={`text-white font-medium ${small ? "text-xs truncate" : "text-sm"} truncate`}>{value}</div>
      </div>
    </div>
  );
}