import { Star } from "lucide-react";

const REVIEWS = [
  {
    name: "Ahmed Raza",
    role: "Content Creator",
    text: "Got my ChatGPT Plus within minutes. Super smooth process and the support was incredibly helpful. Highly recommend PrimeStack!",
    rating: 5,
  },
  {
    name: "Sana Khan",
    role: "Freelance Designer",
    text: "Canva Pro for 3 years at this price is unbeatable. Activation was instant and everything works perfectly. Trusted seller for sure.",
    rating: 5,
  },
  {
    name: "Bilal Ahmed",
    role: "Digital Marketer",
    text: "Bought the Gemini Pro 18-month plan. Premium quality, fast delivery, and genuine access. The best AI marketplace in Pakistan.",
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section className="relative py-20 px-4 sm:px-6">
      <div className="mx-auto max-w-6xl">
        <div className="text-center mb-14 ps-reveal">
          <span className="text-xs font-semibold tracking-widest text-blue-400 uppercase">
            Testimonials
          </span>
          <h2 className="mt-3 font-display font-bold text-white text-[clamp(1.8rem,4vw,2.8rem)] tracking-tight">
            Loved by Creators
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-5">
          {REVIEWS.map((r) => (
            <div
              key={r.name}
              className="ps-reveal rounded-2xl p-6 flex flex-col"
              style={{
                background: "rgba(255,255,255,0.03)",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(255,255,255,0.07)",
              }}
            >
              <div className="flex gap-1 mb-4">
                {Array.from({ length: r.rating }).map((_, i) => (
                  <Star key={i} size={15} className="text-yellow-400 fill-yellow-400" />
                ))}
              </div>
              <p className="text-white/65 text-sm leading-relaxed flex-1">
                "{r.text}"
              </p>
              <div className="mt-5 flex items-center gap-3">
                <div
                  className="flex items-center justify-center rounded-full text-white font-semibold text-sm"
                  style={{
                    width: 40,
                    height: 40,
                    background:
                      "linear-gradient(135deg, #3B82F6, #8B5CF6, #EC4899)",
                  }}
                >
                  {r.name.charAt(0)}
                </div>
                <div>
                  <div className="text-white text-sm font-medium">{r.name}</div>
                  <div className="text-white/40 text-xs">{r.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}