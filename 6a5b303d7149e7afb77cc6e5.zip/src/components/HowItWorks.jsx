import { MousePointerClick, MessageCircle, Rocket } from "lucide-react";

const STEPS = [
  {
    icon: MousePointerClick,
    title: "Choose Your Tool",
    desc: "Browse the marketplace and pick the premium AI product that fits your needs.",
  },
  {
    icon: MessageCircle,
    title: "Order on WhatsApp",
    desc: "Click Buy — your product details are auto-filled and sent straight to our WhatsApp.",
  },
  {
    icon: Rocket,
    title: "Get Delivered",
    desc: "Complete payment, receive instant activation, and start using your premium access.",
  },
];

export default function HowItWorks() {
  return (
    <section className="relative py-20 px-4 sm:px-6">
      <div className="mx-auto max-w-6xl">
        <div className="text-center mb-14 ps-reveal">
          <span className="text-xs font-semibold tracking-widest text-violet-400 uppercase">
            Simple Process
          </span>
          <h2 className="mt-3 font-display font-bold text-white text-[clamp(1.8rem,4vw,2.8rem)] tracking-tight">
            How It Works
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {STEPS.map((s, i) => (
            <div
              key={s.title}
              className="ps-reveal relative rounded-2xl p-7 text-center"
              style={{
                background: "rgba(255,255,255,0.03)",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(255,255,255,0.07)",
              }}
            >
              <div className="absolute top-5 right-6 font-display font-bold text-5xl text-white/5">
                {i + 1}
              </div>
              <div
                className="mx-auto mb-5 flex items-center justify-center rounded-2xl"
                style={{
                  width: 56,
                  height: 56,
                  background:
                    "linear-gradient(135deg, rgba(59,130,246,0.15), rgba(139,92,246,0.15), rgba(236,72,153,0.15))",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
              >
                <s.icon className="text-white" size={24} />
              </div>
              <h3 className="font-display font-semibold text-white text-lg mb-2">
                {s.title}
              </h3>
              <p className="text-white/55 text-sm leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}