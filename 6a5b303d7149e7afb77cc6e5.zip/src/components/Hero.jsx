import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, ArrowRight } from "lucide-react";
import { HERO_PRODUCTS } from "@/data/products";
import { openWhatsApp } from "@/lib/whatsapp";
import ParticleBackground from "@/components/ParticleBackground";

const SPRING = { duration: 0.6, ease: [0.16, 1, 0.3, 1] };

export default function Hero() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const timerRef = useRef(null);

  const product = HERO_PRODUCTS[index];

  useEffect(() => {
    if (paused) return;
    timerRef.current = setInterval(() => {
      setIndex((i) => (i + 1) % HERO_PRODUCTS.length);
    }, 5000);
    return () => clearInterval(timerRef.current);
  }, [paused]);

  const go = (i) => setIndex((i + HERO_PRODUCTS.length) % HERO_PRODUCTS.length);

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center overflow-hidden pt-20 pb-12"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      {/* dynamic background layers */}
      <div className="absolute inset-0 -z-10 bg-[#050505]" />
      <motion.div
        className="absolute inset-0 -z-10"
        animate={{
          background: `radial-gradient(ellipse 80% 60% at 50% 40%, ${product.color}22, transparent 70%), radial-gradient(ellipse 60% 50% at 80% 80%, ${product.color2}1a, transparent 70%)`,
        }}
        transition={{ duration: 0.8, ease: "easeInOut" }}
      />
      <div className="absolute inset-0 -z-10 opacity-70">
        <ParticleBackground color={product.particle} />
      </div>
      {/* glow orbs */}
      <motion.div
        className="absolute -z-10 rounded-full blur-[120px]"
        style={{ width: 400, height: 400, top: "10%", left: "55%" }}
        animate={{ background: `${product.color}40` }}
        transition={{ duration: 0.8 }}
      />
      <motion.div
        className="absolute -z-10 rounded-full blur-[120px]"
        style={{ width: 320, height: 320, bottom: "5%", left: "10%" }}
        animate={{ background: `${product.color2}30` }}
        transition={{ duration: 0.8 }}
      />

      <div className="mx-auto max-w-7xl w-full px-4 sm:px-6 grid lg:grid-cols-[55%_45%] gap-10 lg:gap-8 items-center">
        {/* LEFT — text */}
        <div className="order-2 lg:order-1 text-center lg:text-left">
          <AnimatePresence mode="wait">
            <motion.div
              key={product.id}
              initial={{ opacity: 0, x: 30, filter: "blur(6px)" }}
              animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, x: -30, filter: "blur(6px)" }}
              transition={SPRING}
            >
              <span
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-5"
                style={{
                  background: `${product.color}1a`,
                  border: `1px solid ${product.color}40`,
                  color: product.color,
                }}
              >
                {product.tag}
              </span>

              <h1 className="font-display font-bold text-white leading-[1.05] tracking-tight text-[clamp(2.4rem,6vw,4.5rem)]">
                {product.name}
              </h1>

              <p className="mt-4 text-white/60 text-base sm:text-lg max-w-xl mx-auto lg:mx-0 leading-relaxed">
                {product.description}
              </p>

              {/* price block */}
              <div className="mt-6 flex items-center justify-center lg:justify-start gap-3 flex-wrap">
                {product.oldPrice && (
                  <span className="text-white/35 text-lg line-through">
                    {product.oldPrice}
                  </span>
                )}
                <span
                  className="text-3xl sm:text-4xl font-bold"
                  style={{ color: product.color }}
                >
                  {product.price}
                </span>
                <span className="ps-pulse px-2.5 py-1 rounded-full text-xs font-bold bg-white/8 border border-white/15 bg-gradient-to-r from-blue-400 via-violet-400 to-pink-400 bg-clip-text text-transparent">
                  10% OFF
                </span>
              </div>

              {/* CTAs */}
              <div className="mt-7 flex items-center justify-center lg:justify-start gap-3 flex-wrap">
                <a
                  href="#products"
                  className="flex items-center gap-2 px-6 py-3.5 rounded-xl text-sm font-semibold text-white border border-white/15 bg-white/5 hover:bg-white/10 transition-all duration-300 hover:scale-[1.02]"
                >
                  Explore <ArrowRight size={16} />
                </a>
                <button
                  onClick={() =>
                    openWhatsApp(product.name, product.duration, product.price)
                  }
                  className="flex items-center gap-2 px-6 py-3.5 rounded-xl text-sm font-semibold text-white transition-all duration-300 hover:scale-[1.02]"
                  style={{
                    background: "linear-gradient(135deg, #25D366, #128C7E)",
                    boxShadow: `0 4px 24px ${product.color}40`,
                  }}
                >
                  <MessageCircle size={16} />
                  Buy on WhatsApp
                </button>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* dot navigation */}
          <div className="mt-8 flex items-center justify-center lg:justify-start gap-2">
            {HERO_PRODUCTS.map((p, i) => (
              <button
                key={p.id}
                onClick={() => go(i)}
                aria-label={`Show ${p.name}`}
                className="rounded-full transition-all duration-300"
                style={{
                  width: i === index ? 28 : 8,
                  height: 8,
                  background:
                    i === index ? product.color : "rgba(255,255,255,0.2)",
                }}
              />
            ))}
          </div>
        </div>

        {/* RIGHT — floating glass logo card */}
        <div className="order-1 lg:order-2 flex justify-center mb-6 lg:mb-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={product.id}
              initial={{ opacity: 0, scale: 0.8, rotate: -6 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.8, rotate: 6 }}
              transition={SPRING}
              className="relative"
            >
              {/* glow behind */}
              <div
                className="absolute inset-0 rounded-[2rem] blur-[60px]"
                style={{ background: `${product.color}50` }}
              />
              <div
                className="ps-float relative flex items-center justify-center rounded-[2rem]"
                style={{
                  width: "min(78vw, 320px)",
                  height: "min(78vw, 320px)",
                  background: "rgba(255,255,255,0.04)",
                  backdropFilter: "blur(40px)",
                  WebkitBackdropFilter: "blur(40px)",
                  border: "1px solid rgba(255,255,255,0.12)",
                  boxShadow: `0 24px 80px rgba(0,0,0,0.5), 0 0 60px ${product.color}30`,
                }}
              >
                {/* shimmer */}
                <span className="ps-shimmer absolute inset-0 rounded-[2rem] overflow-hidden" />
                <img
                  src={product.logo}
                  alt={product.name}
                  className="relative w-1/2 h-1/2 object-contain"
                  style={{ filter: "drop-shadow(0 8px 24px rgba(0,0,0,0.4))" }}
                />
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}