import { ShieldCheck, BadgeCheck, Zap, Headphones, HeartHandshake, Sparkles } from "lucide-react";

const REASONS = [
  { icon: ShieldCheck, title: "100% Secure", desc: "Every transaction is protected and handled with care." },
  { icon: BadgeCheck, title: "Verified Products", desc: "Genuine, premium accounts — no fakes, no shortcuts." },
  { icon: Zap, title: "Instant Delivery", desc: "Most products delivered within minutes of payment." },
  { icon: Headphones, title: "24/7 Support", desc: "Round-the-clock help whenever you need assistance." },
  { icon: HeartHandshake, title: "Trusted Seller", desc: "500+ happy clients and a reputation built on trust." },
  { icon: Sparkles, title: "Premium Service", desc: "A curated catalog of only the best AI tools available." },
];

export default function WhyUs() {
  return (
    <section id="why-us" className="relative py-20 px-4 sm:px-6">
      <div className="mx-auto max-w-6xl">
        <div className="text-center mb-14 ps-reveal">
          <span className="text-xs font-semibold tracking-widest text-pink-400 uppercase">
            Why PrimeStack
          </span>
          <h2 className="mt-3 font-display font-bold text-white text-[clamp(1.8rem,4vw,2.8rem)] tracking-tight">
            Why Choose Us
          </h2>
          <p className="mt-3 text-white/50 text-base max-w-xl mx-auto">
            Everything premium. One trusted platform.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {REASONS.map((r) => (
            <div
              key={r.title}
              className="ps-reveal group rounded-2xl p-6 transition-all duration-400 hover:-translate-y-1"
              style={{
                background: "rgba(255,255,255,0.03)",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(255,255,255,0.07)",
              }}
            >
              <div
                className="mb-4 flex items-center justify-center rounded-xl transition-transform duration-300 group-hover:scale-110"
                style={{
                  width: 48,
                  height: 48,
                  background:
                    "linear-gradient(135deg, rgba(59,130,246,0.15), rgba(139,92,246,0.15), rgba(236,72,153,0.15))",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
              >
                <r.icon className="text-white" size={20} />
              </div>
              <h3 className="font-display font-semibold text-white text-base mb-1.5">
                {r.title}
              </h3>
              <p className="text-white/55 text-sm leading-relaxed">{r.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}