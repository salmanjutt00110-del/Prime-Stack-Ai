import { Check, MessageCircle, ArrowUpRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { openWhatsApp } from "@/lib/whatsapp";

export default function ProductCard({ product, index = 0 }) {
  const navigate = useNavigate();

  return (
    <div
      className="ps-reveal group relative rounded-2xl p-6 flex flex-col transition-all duration-400 hover:-translate-y-1.5 cursor-pointer"
      style={{
        background: "rgba(255,255,255,0.03)",
        backdropFilter: "blur(20px)",
        WebkitBackdropFilter: "blur(20px)",
        border: "1px solid rgba(255,255,255,0.07)",
        transitionTimingFunction: "cubic-bezier(0.16,1,0.3,1)",
      }}
      onClick={() => navigate(`/product/${product.id}`)}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)";
        e.currentTarget.style.background = "rgba(255,255,255,0.06)";
        e.currentTarget.style.boxShadow = `0 24px 80px rgba(0,0,0,0.4), 0 0 40px ${product.color}40`;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = "rgba(255,255,255,0.07)";
        e.currentTarget.style.background = "rgba(255,255,255,0.03)";
        e.currentTarget.style.boxShadow = "none";
      }}
    >
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-2/3 h-px"
        style={{ background: `linear-gradient(90deg, transparent, ${product.color}, transparent)` }}
      />

      <div className="flex items-center gap-3 mb-4">
        <div
          className="flex items-center justify-center rounded-xl overflow-hidden shrink-0"
          style={{ width: 52, height: 52, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}
        >
          <img src={product.logo} alt={product.name} className="w-8 h-8 object-contain" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="font-display font-semibold text-white text-[15px] leading-tight truncate">
            {product.name}
          </h3>
          <span
            className="inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-medium"
            style={{ background: `${product.color}1a`, color: product.color }}
          >
            {product.duration}
          </span>
        </div>
        <ArrowUpRight size={18} className="text-white/30 group-hover:text-white/70 transition-colors shrink-0" />
      </div>

      {product.tag && (
        <div className="mb-3">
          <span className="inline-block px-2.5 py-1 rounded-full text-[10px] font-bold bg-white/8 border border-white/12 text-white/80">
            {product.tag}
          </span>
        </div>
      )}

      <ul className="flex-1 space-y-2 mb-5">
        {product.features.slice(0, 5).map((f) => (
          <li key={f} className="flex items-start gap-2 text-[13px] text-white/65">
            <Check size={15} className="mt-0.5 shrink-0" style={{ color: product.color }} />
            <span>{f}</span>
          </li>
        ))}
        {product.features.length > 5 && (
          <li className="text-[12px] text-white/40 pl-7">+{product.features.length - 5} more features</li>
        )}
      </ul>

      {product.warrantyNote && (
        <p className="text-[11px] text-white/35 mb-4 leading-relaxed">{product.warrantyNote}</p>
      )}

      <div className="flex items-center gap-2 mb-4">
        {product.oldPrice && (
          <span className="text-white/35 text-sm line-through">{product.oldPrice}</span>
        )}
        <span className="text-xl font-bold" style={{ color: product.color }}>
          {product.price}
        </span>
        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-gradient-to-r from-blue-400 via-violet-400 to-pink-400 bg-clip-text text-transparent border border-white/12 bg-white/5">
          10% OFF
        </span>
      </div>

      <div className="flex gap-2">
        <button
          onClick={(e) => {
            e.stopPropagation();
            openWhatsApp(product.name, product.duration, product.price);
          }}
          className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold text-white transition-all duration-300 hover:scale-[1.02]"
          style={{ background: "linear-gradient(135deg, #25D366, #128C7E)", boxShadow: "0 4px 20px rgba(37,211,102,0.25)" }}
        >
          <MessageCircle size={15} />
          Buy
        </button>
        <button
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/product/${product.id}`);
          }}
          className="px-4 py-3 rounded-xl text-sm font-medium text-white/80 border border-white/12 hover:bg-white/8 transition-colors"
        >
          Details
        </button>
      </div>
    </div>
  );
}