import { useMemo, useState } from "react";
import { Search, X } from "lucide-react";
import { ALL_PRODUCTS } from "@/data/products";
import ProductCard from "@/components/ProductCard";

export default function ProductsGrid() {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return ALL_PRODUCTS;
    return ALL_PRODUCTS.filter((p) =>
      [p.name, p.duration, p.tag, ...p.features].join(" ").toLowerCase().includes(q)
    );
  }, [query]);

  return (
    <section id="products" className="relative py-20 px-4 sm:px-6">
      <div className="mx-auto max-w-7xl">
        <div className="text-center mb-10 ps-reveal">
          <span className="text-xs font-semibold tracking-widest text-blue-400 uppercase">
            Marketplace
          </span>
          <h2 className="mt-3 font-display font-bold text-white text-[clamp(1.8rem,4vw,2.8rem)] tracking-tight">
            All Premium Products
          </h2>
          <p className="mt-3 text-white/50 text-base">
            Choose your tool. Unlock your potential.
          </p>

          {/* search */}
          <div className="mt-7 mx-auto max-w-md relative">
            <Search
              size={18}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none"
            />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products, features, duration..."
              className="w-full pl-11 pr-10 py-3.5 rounded-full text-sm text-white placeholder-white/35 outline-none transition-all focus:ring-2"
              style={{
                background: "rgba(255,255,255,0.04)",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(255,255,255,0.1)",
              }}
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white p-1"
                aria-label="Clear search"
              >
                <X size={16} />
              </button>
            )}
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-white/50 text-sm">
              No products found for "{query}". Try a different search.
            </p>
            <button
              onClick={() => setQuery("")}
              className="mt-4 px-5 py-2.5 rounded-full text-sm font-medium text-white border border-white/15 hover:bg-white/8 transition-colors"
            >
              Clear search
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {filtered.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}