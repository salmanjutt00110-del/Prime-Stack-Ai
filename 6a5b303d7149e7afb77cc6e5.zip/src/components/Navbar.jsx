import { useEffect, useState } from "react";
import { Menu, X, MessageCircle, Search } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import Logo from "@/components/Logo";
import { WHATSAPP_GENERAL } from "@/lib/whatsapp";

const LINKS = [
  { label: "Home", href: "#home" },
  { label: "Products", href: "#products" },
  { label: "About", href: "#why-us" },
  { label: "Reviews", href: "/reviews", route: true },
  { label: "FAQ", href: "#faq" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNav = (e, link) => {
    e.preventDefault();
    setOpen(false);
    if (link.route) {
      navigate(link.href);
      return;
    }
    if (location.pathname === "/") {
      const el = document.querySelector(link.href);
      if (el) {
        el.scrollIntoView({ behavior: "smooth" });
      }
    } else {
      navigate("/" + link.href);
    }
  };

  return (
    <header
      className="fixed top-0 inset-x-0 z-50 transition-all duration-500"
      style={{
        height: scrolled ? 52 : 64,
        backdropFilter: "blur(24px) saturate(180%)",
        WebkitBackdropFilter: "blur(24px) saturate(180%)",
        background: "rgba(5,5,5,0.85)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 h-full flex items-center justify-between">
        <a href="#home" onClick={(e) => handleNav(e, { href: "#home", route: false })} className="flex items-center gap-2.5 group">
          <Logo size={scrolled ? 32 : 36} />
          <span
            className="font-display font-semibold tracking-tight text-white transition-all"
            style={{ fontSize: scrolled ? 16 : 17 }}
          >
            PrimeStack{" "}
            <span className="ps-grad-text bg-gradient-to-r from-blue-400 via-violet-400 to-pink-400 bg-clip-text text-transparent">
              AI
            </span>
          </span>
        </a>

        <div className="hidden md:flex items-center gap-8">
          {LINKS.map((l) => (
            <a
              key={l.label}
              href={l.route ? l.href : "#" + l.href}
              onClick={(e) => handleNav(e, l)}
              className="text-sm text-white/65 hover:text-white transition-colors duration-300 relative group"
            >
              {l.label}
              <span className="absolute -bottom-1.5 left-0 w-0 h-px bg-gradient-to-r from-blue-400 to-pink-400 group-hover:w-full transition-all duration-300" />
            </a>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={(e) => handleNav(e, { href: "#products", route: false })}
            className="hidden sm:flex items-center gap-2 px-3.5 py-2 rounded-full text-sm text-white/75 hover:text-white border border-white/12 hover:bg-white/8 transition-all"
            aria-label="Search products"
          >
            <Search size={15} />
            Search
          </button>
          <a
            href={WHATSAPP_GENERAL}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold text-white transition-all duration-300 hover:scale-[1.03] hover:shadow-lg"
            style={{ background: "linear-gradient(135deg, #25D366, #128C7E)", boxShadow: "0 4px 20px rgba(37,211,102,0.25)" }}
          >
            <MessageCircle size={16} />
            WhatsApp
          </a>
          <button
            onClick={() => setOpen((v) => !v)}
            className="md:hidden text-white p-2"
            aria-label="Toggle menu"
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </nav>

      <div
        className={`md:hidden overflow-hidden transition-all duration-400 ${open ? "max-h-96" : "max-h-0"}`}
        style={{
          background: "rgba(5,5,5,0.95)",
          backdropFilter: "blur(24px)",
          borderBottom: open ? "1px solid rgba(255,255,255,0.06)" : "none",
        }}
      >
        <div className="px-6 py-4 flex flex-col gap-1">
          {LINKS.map((l) => (
            <a
              key={l.label}
              href={l.route ? l.href : "#" + l.href}
              onClick={(e) => handleNav(e, l)}
              className="py-3 text-white/75 hover:text-white border-b border-white/5 text-sm"
            >
              {l.label}
            </a>
          ))}
          <a
            href={WHATSAPP_GENERAL}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => setOpen(false)}
            className="mt-3 flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-semibold text-white"
            style={{ background: "linear-gradient(135deg, #25D366, #128C7E)" }}
          >
            <MessageCircle size={16} />
            Chat on WhatsApp
          </a>
        </div>
      </div>
    </header>
  );
}